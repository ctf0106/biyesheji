/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.1.49-community : Database - mystock
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mystock` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `mystock`;

/*Table structure for table `bsd` */

DROP TABLE IF EXISTS `bsd`;

CREATE TABLE `bsd` (
  `djid` varchar(14) NOT NULL,
  `riqi` date NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `userid` (`userid`),
  CONSTRAINT `bsd_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='报损单';

/*Data for the table `bsd` */

insert  into `bsd`(`djid`,`riqi`,`userid`,`username`,`bz`) values ('BS201709020001','2017-09-02',1,'管理员',''),('BS201709090001','2017-09-09',1,'管理员','xx'),('BS201709100001','2017-09-10',1,'管理员','ccc'),('BS201801270001','2018-01-27',1,'管理员',''),('BS201801270002','2018-01-27',1,'管理员','');

/*Table structure for table `bsdsp` */

DROP TABLE IF EXISTS `bsdsp`;

CREATE TABLE `bsdsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `F_Bsdsp_Bsd` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `bsdsp_ibfk_1` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`),
  CONSTRAINT `F_Bsdsp_Bsd` FOREIGN KEY (`djid`) REFERENCES `bsd` (`djid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='报损单商品';

/*Data for the table `bsdsp` */

insert  into `bsdsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`dj`,`sl`,`zj`) values (1,'BS201709020001','0002','维生素C','瓶','0.1g*100',16,1,16),(2,'BS201709090001','0002','维生素C','瓶','0.1g*100',16,1,16),(3,'BS201709100001','0011','三百草','g','',46,1,46),(4,'BS201801270001','0005','加味保和丸','瓶','6G*100',13,0,0),(5,'BS201801270002','0006','四季三黄片','瓶','0.55g*100',13,0,0);

/*Table structure for table `byd` */

DROP TABLE IF EXISTS `byd`;

CREATE TABLE `byd` (
  `djid` varchar(14) NOT NULL,
  `riqi` date NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `userid` (`userid`),
  CONSTRAINT `byd_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='报溢单';

/*Data for the table `byd` */

insert  into `byd`(`djid`,`riqi`,`userid`,`username`,`bz`) values ('BY201709020001','2017-09-02',1,'管理员','cc'),('BY201709100001','2017-09-10',1,'管理员','cc');

/*Table structure for table `bydsp` */

DROP TABLE IF EXISTS `bydsp`;

CREATE TABLE `bydsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `FK_Bydsp_Byd` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `bydsp_ibfk_1` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`),
  CONSTRAINT `FK_Bydsp_Byd` FOREIGN KEY (`djid`) REFERENCES `byd` (`djid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='报溢单商品';

/*Data for the table `bydsp` */

insert  into `bydsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`dj`,`sl`,`zj`) values (1,'BY201709020001','0006','四季三黄片','瓶','0.55g*100',18,2,36),(2,'BY201709100001','0012','虫牙草','g','',78,2,156);

/*Table structure for table `ckd` */

DROP TABLE IF EXISTS `ckd`;

CREATE TABLE `ckd` (
  `djid` varchar(14) NOT NULL,
  `khid` int(11) DEFAULT NULL COMMENT '供应商id',
  `khname` varchar(50) DEFAULT NULL,
  `riqi` date NOT NULL,
  `yfje` double DEFAULT NULL,
  `sfje` double DEFAULT NULL,
  `cbje` double DEFAULT NULL,
  `jystate` varchar(2) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `FK_Ckd_Kh` (`khid`),
  KEY `FK_Ckd_Users` (`userid`),
  CONSTRAINT `FK_Ckd_Kh` FOREIGN KEY (`khid`) REFERENCES `kh` (`khid`) ON DELETE SET NULL,
  CONSTRAINT `FK_Ckd_Users` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='销售出库';

/*Data for the table `ckd` */

insert  into `ckd`(`djid`,`khid`,`khname`,`riqi`,`yfje`,`sfje`,`cbje`,`jystate`,`userid`,`username`,`bz`) values ('XS201709020001',1,'遵义市意通医药','2017-09-02',250,250,200,'1',1,'管理员','ccc'),('XS201709070001',1,'遵义市意通医药','2017-09-07',100,100,80,'1',1,'管理员',''),('XS201709090001',1,'遵义市意通医药','2017-09-09',75,75,60,'1',1,'管理员',''),('XS201709100001',1,'遵义市意通医药','2017-09-10',107,107,6020,'1',1,'管理员','ccc'),('XS201709100002',1,'遵义市意通医药','2017-09-10',30000,30000,25000,'1',1,'管理员','ccc'),('XS201709100003',1,'遵义市意通医药','2017-09-10',273000,273000,227500,'1',1,'管理员','cc'),('XS201801270001',1,'银川市人民医院','2018-01-27',25,25,20,'1',1,'管理员',''),('XS201801270002',1,'银川市人民医院','2018-01-27',16,16,20010.5,'1',1,'管理员',''),('XS201801270003',1,'银川市人民医院','2018-01-27',17820,17820,9900,'1',1,'管理员','');

/*Table structure for table `ckdsp` */

DROP TABLE IF EXISTS `ckdsp`;

CREATE TABLE `ckdsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `lbid` int(11) DEFAULT NULL,
  `lbname` varchar(20) DEFAULT NULL,
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `FK_Ckdsp_Ckd` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `ckdsp_ibfk_1` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`),
  CONSTRAINT `FK_Ckdsp_Ckd` FOREIGN KEY (`djid`) REFERENCES `ckd` (`djid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='销售单商品';

/*Data for the table `ckdsp` */

insert  into `ckdsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`lbid`,`lbname`,`dj`,`sl`,`zj`) values (1,'XS201709020001','0011','三百草','g','',3,'中草药',59,10,590),(2,'XS201709090001','0012','虫牙草','g','',3,'中草药',78,3,234),(3,'XS201709070001','0001','去甲肾上腺素','支','2mg*1',1,'西药',25,1,25),(4,'XS201709100001','0001','去甲肾上腺素','支','2mg*1',1,'西药',25,3,75),(8,'XS201801270001','0001',' 去甲肾上腺素','支',' 	2mg*1',1,'西药',25,1,25),(9,'XS201801270002','0002','维生素C','瓶',' 	0.1g*100',1,'西药',16,1,16),(10,'XS201801270003','0006','四季三黄片','瓶','0.55g*100',2,'中成药',18,990,17820);

/*Table structure for table `gys` */

DROP TABLE IF EXISTS `gys`;

CREATE TABLE `gys` (
  `gysid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `lxren` varchar(30) DEFAULT NULL COMMENT '联系人',
  `lxtel` varchar(30) DEFAULT NULL COMMENT '联系电话',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`gysid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='供应商';

/*Data for the table `gys` */

insert  into `gys`(`gysid`,`name`,`lxren`,`lxtel`,`address`,`bz`) values (2,'遵义市意通医药','张三2','2131232112','xxx2','x2'),(3,'国药控股贵州','李四','2321321312','xxx','xxxx'),(4,'贵州国泰医药','小凡','1234566654','xxx','xxx'),(5,'7 7','','','','');

/*Table structure for table `jhd` */

DROP TABLE IF EXISTS `jhd`;

CREATE TABLE `jhd` (
  `djid` varchar(14) NOT NULL,
  `gysid` int(11) DEFAULT NULL,
  `gysname` varchar(50) DEFAULT NULL,
  `riqi` date NOT NULL,
  `yfje` double DEFAULT NULL,
  `sfje` double DEFAULT NULL,
  `jystate` varchar(2) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `FK_Jhd_Gys` (`gysid`),
  KEY `FK_Jhd_Users` (`userid`),
  CONSTRAINT `FK_Jhd_Gys` FOREIGN KEY (`gysid`) REFERENCES `gys` (`gysid`) ON DELETE SET NULL,
  CONSTRAINT `FK_Jhd_Users` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='进货单';

/*Data for the table `jhd` */

insert  into `jhd`(`djid`,`gysid`,`gysname`,`riqi`,`yfje`,`sfje`,`jystate`,`userid`,`username`,`bz`) values ('JH201709020001',2,'遵义市意通医药','2017-09-02',200,200,'1',1,'管理员',''),('JH201709020002',3,'国药控股贵州','2017-09-02',10,10,'1',1,'管理员','xxx'),('JH201709020003',3,'王大路食品公司','2017-09-02',40,40,'1',1,'管理员','xccc'),('JH201709080001',2,'遵义市意通医药','2017-09-08',24,24,'1',1,'管理员','cc'),('JH201709100001',4,'贵州国泰医药','2017-09-10',16,16,'0',1,'管理员','ccc'),('JH201801260001',2,'遵义市意通医药','2018-01-26',20,20,'1',1,'管理员',''),('JH201801270001',3,'国药控股贵州','2018-01-27',1100,1100,'1',1,'管理员',''),('JH201801270002',3,'国药控股贵州','2018-01-27',1100,1100,'1',1,'管理员',''),('JH201801270003',3,'国药控股贵州','2018-01-27',52,52,'1',1,'管理员','');

/*Table structure for table `jhdsp` */

DROP TABLE IF EXISTS `jhdsp`;

CREATE TABLE `jhdsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `lbid` int(11) DEFAULT NULL,
  `lbname` varchar(20) DEFAULT NULL,
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `Fk_JhdSp_Jhd` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `Fk_JhdSp_Jhd` FOREIGN KEY (`djid`) REFERENCES `jhd` (`djid`) ON DELETE CASCADE,
  CONSTRAINT `jhdsp_ibfk_1` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='进货单商品';

/*Data for the table `jhdsp` */

insert  into `jhdsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`lbid`,`lbname`,`dj`,`sl`,`zj`) values (1,'JH201709020001','0001','去甲肾上腺素','支',' 	2mg*1',1,'西药',25,2,50),(2,'JH201709020002','0002','维生素C','瓶','0.1g*100',1,'西药',16,10,160),(3,'JH201709020003','0002','维生素C','瓶','0.1g*100',1,'西药',16,20,320),(4,'JH201709080001','0001','去甲肾上腺素','支',' 	2mg*1',1,'西药',25,1,25),(5,'JH201709080001','0002','维生素C','瓶','0.1g*100',1,'西药',16,2,32),(6,'JH201709100001','0011','三百草','g','',3,'中草药',59,2,118),(7,'JH201709100001','0002','维生素C','瓶','0.1g*100',1,'西药',16,3,84),(8,'JH201801260001','0001',' 去甲肾上腺素','支',' 	2mg*1',1,'西药',25,1,25),(9,'JH201801270001','0002','维生素C','瓶',' 	0.1g*100',1,'西药',11,100,1100),(10,'JH201801270002','0002','维生素C','瓶',' 	0.1g*100',1,'西药',11,100,1100),(11,'JH201801270003','0003','利福喷丁胶囊','盒',' 	0.15g*20粒',1,'西药',52,1,52);

/*Table structure for table `kh` */

DROP TABLE IF EXISTS `kh`;

CREATE TABLE `kh` (
  `khid` int(11) NOT NULL AUTO_INCREMENT,
  `khname` varchar(50) NOT NULL,
  `lxren` varchar(30) DEFAULT NULL COMMENT '联系人',
  `lxtel` varchar(30) DEFAULT NULL COMMENT '联系电话',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `bz` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`khid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='客户';

/*Data for the table `kh` */

insert  into `kh`(`khid`,`khname`,`lxren`,`lxtel`,`address`,`bz`) values (1,'银川市人民医院','小苏','3242343232','sss','ssss'),(2,'灵武市中医医院','jack','421321312','ccc','ccc'),(3,'银川附属医院','小样','13468446754','ddd','dddd');

/*Table structure for table `menu` */

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `menuid` int(11) NOT NULL,
  `menuname` varchar(20) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `menuurl` varchar(100) DEFAULT NULL,
  `menutype` int(11) NOT NULL,
  `ordernum` int(11) DEFAULT NULL,
  `icon` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单目录';

/*Data for the table `menu` */

insert  into `menu`(`menuid`,`menuname`,`pid`,`menuurl`,`menutype`,`ordernum`,`icon`) values (0,'系统菜单',-1,NULL,1,0,'menu-plugin'),(10,'药品进货管理',0,NULL,1,1,'menu-1'),(20,'药品销售管理',0,NULL,1,2,'menu-2'),(30,'药品库存管理',0,NULL,1,3,'menu-3'),(40,'统计报表',0,NULL,1,4,'menu-4'),(50,'基础资料',0,NULL,1,5,'menu-5'),(60,'系统管理',0,NULL,1,6,'menu-6'),(1010,'进货入库',10,'../jinhuo/jinhuo.jsp',0,1,'menu-11'),(1020,'退货出库',10,'../jinhuo/tuihuo.jsp',0,2,'menu-12'),(1030,'进货单据查询',10,'../jinhuo/jinsearch.jsp',0,3,'menu-13'),(1040,'退货单据查询',10,'../jinhuo/mingxi.jsp',0,4,'menu-14'),(1050,'当前库存查询',10,'../kucun/kcsearch.jsp',0,5,'menu-15'),(2010,'销售出库',20,'../chushou/chuku.jsp',0,1,'menu-21'),(2020,'客户退货',20,'../chushou/tuiku.jsp',0,2,'menu-22'),(2030,'销售单据查询',20,'../chushou/chusearch.jsp',0,3,'menu-23'),(2040,'客户退货查询',20,'../chushou/mingxi.jsp',0,4,'menu-24'),(2050,'当前库存查询',20,'../kucun/kcsearch.jsp',0,5,'menu-25'),(3010,'药品报损',30,'../kucun/baosun.jsp',0,1,'menu-31'),(3020,'药品报溢',30,'../kucun/baoyi.jsp',0,2,'menu-32'),(3030,'库存报警',30,'../kucun/baojing.jsp',0,3,'menu-33'),(3040,'报损报溢查询',30,'../kucun/biansearch.jsp',0,4,'menu-34'),(3050,'当前库存查询',30,'../kucun/kcsearch.jsp',0,5,'menu-35'),(4010,'供应商统计',40,'../tongji/gystj.jsp',0,1,'menu-41'),(4020,'客户统计',40,'../tongji/khtj.jsp',0,2,'menu-42'),(4030,'药品采购统计',40,'../tongji/spcgtj.jsp',0,3,'menu-43'),(4040,'药品销售统计',40,'../tongji/spxstj.jsp',0,4,'menu-44'),(4050,'按日统计分析',40,'../tongji/tjfxri.jsp',0,5,'menu-45'),(4060,'按月统计分析',40,'../tongji/tjfxyue.jsp',0,6,'menu-46'),(5010,'供应商管理',50,'../ziliao/gys.jsp',0,1,'menu-51'),(5020,'客户管理',50,'../ziliao/kh.jsp',0,2,'menu-52'),(5030,'药品管理',50,'../ziliao/spxx.jsp',0,3,'menu-53'),(5040,'期初库存',50,'../ziliao/kc.jsp',0,4,'menu-54'),(6010,'角色管理',60,'../power/role.jsp',0,1,'menu-61'),(6020,'用户管理',60,'../power/user.jsp',0,2,'menu-62');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(20) NOT NULL,
  `bz` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='角色表';

/*Data for the table `role` */

insert  into `role`(`roleid`,`rolename`,`bz`) values (1,'管理员','系统管理'),(2,'主管','公司主管'),(3,'业务员','ccc');

/*Table structure for table `rolemenu` */

DROP TABLE IF EXISTS `rolemenu`;

CREATE TABLE `rolemenu` (
  `roleid` int(11) NOT NULL,
  `menuid` int(11) NOT NULL,
  PRIMARY KEY (`roleid`,`menuid`),
  KEY `menuid` (`menuid`),
  CONSTRAINT `rolemenu_ibfk_3` FOREIGN KEY (`menuid`) REFERENCES `menu` (`menuid`) ON DELETE CASCADE,
  CONSTRAINT `rolemenu_ibfk_4` FOREIGN KEY (`roleid`) REFERENCES `role` (`roleid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色菜单';

/*Data for the table `rolemenu` */

insert  into `rolemenu`(`roleid`,`menuid`) values (1,10),(2,10),(3,10),(1,20),(3,20),(1,30),(3,30),(1,40),(1,50),(1,60),(1,1010),(2,1010),(3,1010),(1,1020),(2,1020),(3,1020),(1,1030),(2,1030),(3,1030),(1,1040),(2,1040),(3,1040),(1,1050),(2,1050),(3,1050),(1,2010),(3,2010),(1,2020),(3,2020),(1,2030),(3,2030),(1,2040),(3,2040),(1,2050),(3,2050),(1,3010),(3,3010),(1,3020),(3,3020),(1,3030),(3,3030),(1,3040),(3,3040),(1,3050),(3,3050),(1,4010),(1,4020),(1,4030),(1,4040),(1,4050),(1,4060),(1,5010),(1,5020),(1,5030),(1,5040),(1,6010),(1,6020);

/*Table structure for table `spdw` */

DROP TABLE IF EXISTS `spdw`;

CREATE TABLE `spdw` (
  `dwid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `dwname` varchar(20) NOT NULL,
  PRIMARY KEY (`dwid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='货物单位';

/*Data for the table `spdw` */

insert  into `spdw`(`dwid`,`dwname`) values (1,'盒'),(2,'袋'),(3,'支'),(4,'Kg'),(5,'g'),(6,'瓶'),(7,'袋');

/*Table structure for table `splb` */

DROP TABLE IF EXISTS `splb`;

CREATE TABLE `splb` (
  `lbid` int(11) NOT NULL AUTO_INCREMENT,
  `lbname` varchar(20) DEFAULT NULL COMMENT '类别名称',
  `pid` int(11) DEFAULT NULL COMMENT '父类别id',
  PRIMARY KEY (`lbid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='商品类别';

/*Data for the table `splb` */

insert  into `splb`(`lbid`,`lbname`,`pid`) values (1,'西药',0),(2,'中成药',0),(3,'中草药',0);

/*Table structure for table `spxx` */

DROP TABLE IF EXISTS `spxx`;

CREATE TABLE `spxx` (
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) NOT NULL COMMENT '货物名称',
  `xinghao` varchar(20) DEFAULT NULL COMMENT '型号',
  `lbid` int(11) NOT NULL COMMENT '类别id',
  `lbname` varchar(20) NOT NULL,
  `dw` varchar(10) DEFAULT NULL COMMENT '单位',
  `jhprice` double DEFAULT '0',
  `chprice` double DEFAULT '0',
  `scjj` double DEFAULT '0',
  `kcsl` int(11) DEFAULT '0',
  `kczj` double DEFAULT '0',
  `minnum` int(11) DEFAULT '0',
  `csname` varchar(50) DEFAULT NULL,
  `state` varchar(1) DEFAULT '0',
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`spid`),
  KEY `FK_Spxx_Splb` (`lbid`),
  CONSTRAINT `FK_Spxx_Splb` FOREIGN KEY (`lbid`) REFERENCES `splb` (`lbid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品';

/*Data for the table `spxx` */

insert  into `spxx`(`spid`,`spname`,`xinghao`,`lbid`,`lbname`,`dw`,`jhprice`,`chprice`,`scjj`,`kcsl`,`kczj`,`minnum`,`csname`,`state`,`bz`) values ('0001',' 去甲肾上腺素',' 	2mg*1',1,'西药','支',20,25,20,1000,20000,100,' 	远大医药','2','xx'),('0002','维生素C',' 	0.1g*100',1,'西药','瓶',10.5,16,11,399,4189.5,100,' 	山东新华','2','x'),('0003','利福喷丁胶囊',' 	0.15g*20粒',1,'西药','盒',52,60,52,205,10660,100,' 	江苏正大天晴','2','xx'),('0004','阿托伐他汀钙分散片',' 	10mg*7',1,'西药','盒',30,40,29,1101,33030,100,' 	安徽丰原药业','2','xxx'),('0005','加味保和丸','6G*100',2,'中成药','瓶',12,16,13,1011,12132,100,' 	山东新华','2',NULL),('0006','四季三黄片','0.55g*100',2,'中成药','瓶',10,18,13,10,100,100,' 	江苏正大天晴','2',NULL),('0007','加味灵芝菌片','0.15g*20',2,'中成药','盒',11,14,11,1000,11000,100,' 	山东新华','2',NULL),('0008','导赤丸',NULL,2,'中成药','盒',22,30,25,1000,22000,100,' 	山东新华','0',NULL),('0009','益心宁神片','0.13g*20',2,'中成药','盒',13,19,12,1000,13000,100,'远大医药','0',NULL),('0010','千里光','',3,'中草药','g',0,39,0,0,0,100,'安徽丰原药业','0',NULL),('0011','三白草','',3,'中草药','g',46,59,48,1000,46000,100,' 	江苏正大天晴','0',NULL),('0012','虫牙药','',3,'中草药','g',63,78,60,1000,63000,100,' 	江苏正大天晴','0',NULL),('0013','白芍','',3,'中草药','g',21,35,23,1000,21000,100,' 	江苏正大天晴','0',NULL);

/*Table structure for table `thd` */

DROP TABLE IF EXISTS `thd`;

CREATE TABLE `thd` (
  `djid` varchar(14) NOT NULL,
  `gysid` int(11) DEFAULT NULL,
  `gysname` varchar(50) DEFAULT NULL,
  `riqi` date NOT NULL,
  `yfje` double DEFAULT NULL COMMENT '应付金额',
  `sfje` double DEFAULT NULL COMMENT '实付金额',
  `jystate` varchar(2) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `FK_Thd_Gys` (`gysid`),
  KEY `FK_Thd_Users` (`userid`),
  CONSTRAINT `FK_Thd_Gys` FOREIGN KEY (`gysid`) REFERENCES `gys` (`gysid`) ON DELETE SET NULL,
  CONSTRAINT `FK_Thd_Users` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品退库';

/*Data for the table `thd` */

insert  into `thd`(`djid`,`gysid`,`gysname`,`riqi`,`yfje`,`sfje`,`jystate`,`userid`,`username`,`bz`) values ('TH201709020001',3,'国药控股贵州','2017-09-02',6,6,'1',1,'管理员','cc'),('TH201709100001',2,'遵义市意通医药','2017-09-10',5,5,'1',1,'管理员','ccc'),('TH201801270001',2,'遵义市意通医药','2018-01-27',11,11,'1',1,'管理员','');

/*Table structure for table `thdsp` */

DROP TABLE IF EXISTS `thdsp`;

CREATE TABLE `thdsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `lbid` int(11) DEFAULT NULL,
  `lbname` varchar(20) DEFAULT NULL,
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `FK_Thdsp_Thd` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `FK_Thdsp_Thd` FOREIGN KEY (`djid`) REFERENCES `thd` (`djid`) ON DELETE CASCADE,
  CONSTRAINT `thdsp_ibfk_1` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='退货单商品';

/*Data for the table `thdsp` */

insert  into `thdsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`lbid`,`lbname`,`dj`,`sl`,`zj`) values (1,'TH201709020001','0002','维生素C','瓶','0.1*100',1,'西药',16,1,16),(2,'TH201709100001','0011','三百草','g','',3,'中草药',59,2,118),(3,'TH201801270001','0007','加味灵芝菌片','盒','0.15g*20',2,'中成药',11,1,11);

/*Table structure for table `tkd` */

DROP TABLE IF EXISTS `tkd`;

CREATE TABLE `tkd` (
  `djid` varchar(14) NOT NULL,
  `khid` int(11) DEFAULT NULL COMMENT '供应商id',
  `khname` varchar(50) DEFAULT NULL,
  `riqi` date NOT NULL,
  `yfje` double DEFAULT NULL,
  `sfje` double DEFAULT NULL,
  `cbje` double DEFAULT NULL,
  `jystate` varchar(2) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `bz` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`djid`),
  KEY `FK_Tkd_Kh` (`khid`),
  KEY `FK_Tkd_Users` (`userid`),
  CONSTRAINT `FK_Tkd_Kh` FOREIGN KEY (`khid`) REFERENCES `kh` (`khid`) ON DELETE SET NULL,
  CONSTRAINT `FK_Tkd_Users` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户退货';

/*Data for the table `tkd` */

insert  into `tkd`(`djid`,`khid`,`khname`,`riqi`,`yfje`,`sfje`,`cbje`,`jystate`,`userid`,`username`,`bz`) values ('XT201709020001',1,'银川市人民医院','2017-09-02',75,75,60,'1',1,'管理员','cc'),('XT201709100001',2,'灵武市中医医院','2017-09-10',25,25,20,'1',1,'管理员','ccc'),('XT201801270001',1,'银川市人民医院','2018-01-27',14,14,11,'0',1,'管理员',''),('XT201801270002',1,'银川市人民医院','2018-01-27',176,176,110132,'0',1,'管理员','');

/*Table structure for table `tkdsp` */

DROP TABLE IF EXISTS `tkdsp`;

CREATE TABLE `tkdsp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `djid` varchar(14) NOT NULL,
  `spid` varchar(10) NOT NULL COMMENT '商品id',
  `spname` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `spdw` varchar(20) DEFAULT NULL COMMENT '商品单位',
  `spxinghao` varchar(20) DEFAULT NULL COMMENT '规格型号',
  `lbid` int(11) DEFAULT NULL,
  `lbname` varchar(20) DEFAULT NULL,
  `dj` double DEFAULT NULL COMMENT '单价',
  `sl` int(11) DEFAULT NULL COMMENT '数量',
  `zj` double DEFAULT NULL COMMENT '总价',
  PRIMARY KEY (`id`),
  KEY `djid` (`djid`),
  KEY `spid` (`spid`),
  CONSTRAINT `tkdsp_ibfk_4` FOREIGN KEY (`djid`) REFERENCES `tkd` (`djid`) ON DELETE CASCADE,
  CONSTRAINT `tkdsp_ibfk_5` FOREIGN KEY (`spid`) REFERENCES `spxx` (`spid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='客户退货商品';

/*Data for the table `tkdsp` */

insert  into `tkdsp`(`id`,`djid`,`spid`,`spname`,`spdw`,`spxinghao`,`lbid`,`lbname`,`dj`,`sl`,`zj`) values (1,'XT201709020001','0001','去甲肾上腺素','支','2mg*1',1,'西药',25,3,75),(2,'XT201709100001','0001','去甲肾上腺素','支','2mg*1',1,'西药',25,1,25),(3,'XT201801270001','0007','加味灵芝菌片','盒','0.15g*20',2,'中成药',14,1,14),(4,'XT201801270002','0005','加味保和丸','瓶','6G*100',2,'中成药',16,11,176);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `logincode` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `roleid` int(11) DEFAULT NULL,
  `state` int(11) NOT NULL,
  `bz` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `roleid` (`roleid`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `role` (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户表';

/*Data for the table `users` */

insert  into `users`(`userid`,`logincode`,`password`,`username`,`roleid`,`state`,`bz`) values (1,'admin','admin','管理员',1,0,'系统管理员'),(2,'da','dsa','fda',2,0,'dsa'),(3,'jack','123','张三',3,0,'ccc');

/* Trigger structure for table `ckdsp` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `ckdsp_setspxx` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `ckdsp_setspxx` BEFORE DELETE ON `ckdsp` FOR EACH ROW BEGIN
    update spxx set kcsl=kcsl+old.sl,kczj=kcsl*jhprice where spid=old.spid;
END */$$


DELIMITER ;

/* Trigger structure for table `jhdsp` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `jhdsp_setspxx` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `jhdsp_setspxx` BEFORE DELETE ON `jhdsp` FOR EACH ROW BEGIN
    update spxx set kcsl=kcsl-old.sl,kczj=kcsl*jhprice where spid=old.spid;
END */$$


DELIMITER ;

/* Trigger structure for table `thdsp` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `thdsp_setspxx` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `thdsp_setspxx` BEFORE DELETE ON `thdsp` FOR EACH ROW BEGIN
    update spxx set kcsl=kcsl+old.sl,kczj=kcsl*jhprice where spid=old.spid;
END */$$


DELIMITER ;

/* Trigger structure for table `tkdsp` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `tkdsp_setspxx` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `tkdsp_setspxx` BEFORE DELETE ON `tkdsp` FOR EACH ROW BEGIN
    update spxx set kcsl=kcsl-old.sl,kczj=kcsl*jhprice where spid=old.spid;
END */$$


DELIMITER ;

/*Table structure for table `vusermenu` */

DROP TABLE IF EXISTS `vusermenu`;

/*!50001 DROP VIEW IF EXISTS `vusermenu` */;
/*!50001 DROP TABLE IF EXISTS `vusermenu` */;

/*!50001 CREATE TABLE  `vusermenu`(
 `userid` int(11) ,
 `logincode` varchar(20) ,
 `username` varchar(20) ,
 `menuid` int(11) ,
 `menuname` varchar(20) ,
 `pid` int(11) ,
 `menuurl` varchar(100) ,
 `menutype` int(11) ,
 `ordernum` int(11) ,
 `icon` varchar(20) 
)*/;

/*View structure for view vusermenu */

/*!50001 DROP TABLE IF EXISTS `vusermenu` */;
/*!50001 DROP VIEW IF EXISTS `vusermenu` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vusermenu` AS select distinct sql_no_cache `a`.`userid` AS `userid`,`a`.`logincode` AS `logincode`,`a`.`username` AS `username`,`d`.`menuid` AS `menuid`,`d`.`menuname` AS `menuname`,`d`.`pid` AS `pid`,`d`.`menuurl` AS `menuurl`,`d`.`menutype` AS `menutype`,`d`.`ordernum` AS `ordernum`,`d`.`icon` AS `icon` from ((`users` `a` join `rolemenu` `c`) join `menu` `d`) where ((`a`.`roleid` = `c`.`roleid`) and (`c`.`menuid` = `d`.`menuid`)) order by `d`.`ordernum` */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
